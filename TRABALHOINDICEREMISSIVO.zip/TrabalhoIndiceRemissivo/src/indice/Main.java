package indice;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Digite o texto:");
            String texto = LeitorEntrada.lerEntradaUsuario();
            String[] linhasTexto = texto.split("\\n");

            System.out.println("Digite as palavras-chave separadas por espaco:");
            String palavrasEntrada = LeitorEntrada.lerEntradaUsuario();
            String[] palavrasChave = palavrasEntrada.split(" ");

            TabelaHash tabela;
            tabela = new TabelaHash();
            for (int i = 0; i < linhasTexto.length; i++) {
                String[] palavras = linhasTexto[i].split("\\W+");
                for (String palavra : palavras) {
                    if (!palavra.equals("")) {
                        tabela.adicionarPalavra(palavra, i + 1);
                    }
                }
            }

            String indiceRemissivo = tabela.gerarIndice(palavrasChave);
            System.out.println("\nIndice Remissivo:\n" + indiceRemissivo);
        } catch (Exception e) {
            System.out.println("Erro ao processar entrada: " + e.getMessage());
        }
    }
}
