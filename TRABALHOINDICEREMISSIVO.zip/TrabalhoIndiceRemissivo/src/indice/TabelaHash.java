
package indice;

class TabelaHash {
    Palavra[] tabela;

    public TabelaHash() {
        tabela = new Palavra[26];
    }

    public void adicionarPalavra(String palavra, int linha) {
        char chave = Character.toLowerCase(palavra.charAt(0));
        int indice = chave - 'a';
        if (tabela[indice] == null) {
            tabela[indice] = new Palavra(palavra);
            tabela[indice].ocorrencias.adicionar(linha);
        } else {
            Palavra atual = tabela[indice];
            while (atual != null) {
                if (atual.texto.equalsIgnoreCase(palavra)) {
                    atual.ocorrencias.adicionar(linha);
                    return;
                }
                atual = null;
            }
            Palavra novaPalavra = new Palavra(palavra);
            novaPalavra.ocorrencias.adicionar(linha);
            tabela[indice] = novaPalavra;
        }
    }

    public String gerarIndice(String[] palavrasChave) {
        String resultado = "";
        for (String palavra : palavrasChave) {
            char chave = Character.toLowerCase(palavra.charAt(0));
            int indice = chave - 'a';
            if (tabela[indice] != null && tabela[indice].texto.equalsIgnoreCase(palavra)) {
                if (tabela[indice].ocorrencias.estaVazia()) {
                    resultado += palavra + ": Nao encontrada no texto\n";
                } else {
                    resultado += palavra + ": " + tabela[indice].ocorrencias.listarOcorrencias() + "\n";
                }
            } else {
                resultado += palavra + ": Nao encontrada no texto\n";
            }
        }
        return resultado;
    }
}
