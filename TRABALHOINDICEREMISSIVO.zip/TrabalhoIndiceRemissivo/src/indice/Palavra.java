
package indice;

class Palavra {
    String texto;
    ListaEncadeada ocorrencias;

    public Palavra(String texto) {
        this.texto = texto;
        this.ocorrencias = new ListaEncadeada();
    }
}
