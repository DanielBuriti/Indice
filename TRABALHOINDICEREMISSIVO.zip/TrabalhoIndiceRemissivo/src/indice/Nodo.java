
package indice;

class Nodo {
    int linha;
    Nodo proximo;

    public Nodo(int linha) {
        this.linha = linha;
        this.proximo = null;
    }
}