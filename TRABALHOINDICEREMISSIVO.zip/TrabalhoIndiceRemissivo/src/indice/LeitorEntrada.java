
package indice;

class LeitorEntrada {
    public static String lerEntradaUsuario() throws Exception {
        java.io.InputStreamReader isr = new java.io.InputStreamReader(System.in);
        java.io.BufferedReader br = new java.io.BufferedReader(isr);
        return br.readLine().trim();
    }
}
