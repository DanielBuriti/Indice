
package indice;

class ListaEncadeada {
    Nodo inicio;

    public void adicionar(int linha) {
        Nodo novo = new Nodo(linha);
        if (inicio == null) {
            inicio = novo;
        } else {
            Nodo atual = inicio;
            while (atual.proximo != null) {
                atual = atual.proximo;
            }
            atual.proximo = novo;
        }
    }

    public String listarOcorrencias() {
        String resultado = "";
        Nodo atual = inicio;
        while (atual != null) {
            resultado += atual.linha + " ";
            atual = atual.proximo;
        }
        return resultado.trim();
    }

    public boolean estaVazia() {
        return inicio == null;
    }
}
